package com.example.shuttlebus;

import java.util.Calendar;

import android.app.Activity;
import android.app.AlarmManager;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.TaskStackBuilder;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.os.Vibrator;
import android.support.v4.app.NotificationCompat;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Spinner;
import android.widget.Toast;

public class Reminder extends Activity {
	
	//STOPS
	  final String[] northArray = new String[] { "IIT Tower (10 West 35th)", "33rd and Federal - HH Lot",
		      "31st and Federal", "26th and Princeton", "225 S. Canal - Union Station", "Madison Street (btwn Canal and Clinton) - N�Western Station",
		      "Adams and Jefferson (SE Corner) - Adams St. Campus" };
	  
	  final String[] southArray = new String[] { "Adams and Jefferson (SE Corner) - Adams St. Campus", "Clinton Street (btwn Washington and Madison) - N�Western Station",
			  "Clinton and Adams (SW Corner) - Union Station", "26th and Princeton", "31st and Dearborn", "Gunsaulus Hall - 32nd and Michigan", "31st and Indiana", "32nd and King Drive",
			  "Residence Halls (NE Corner) - 33rd and Michigan", "IIT Tower (10 West 35th)"};

	final String[] northArray1 ={"6:24 AM", "6:54 AM", "7:24 AM", "7:59 AM", "8:29 AM", "3:54 AM", "4:24 AM", 
				"4:49 AM", "5:09 PM*","5:29 PM*", "8:02 PM", "9:09 PM"};

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_reminder);
		
		buttonOkListener();
	}
	
	//BUTTON OK LISTENER
		public void buttonOkListener() {
			 
			final RadioGroup radioDirections = (RadioGroup) findViewById(R.id.radioGroupR);
			Button btnOk = (Button) findViewById(R.id.ok2);
			
			btnOk.setOnClickListener(new OnClickListener() {
				@Override
				public void onClick(View v) {
				// get selected radio button from radioGroup
				int selectedId = radioDirections.getCheckedRadioButtonId();
				// find the radiobutton by returned id
				RadioButton rb = (RadioButton) findViewById(selectedId);
				System.out.println(selectedId);
				
							if (rb.getText().equals("NorthBound")){
								populateNorthSpinner();							
							}
							
							if (rb.getText().equals("SouthBound")){
								populateSouthSpinner();
							}
							
							else
							buttonOkListener();
				}
			});
		}//button listener
		
		public void populateNorthSpinner(){
			final Spinner spinner = (Spinner) findViewById(R.id.spinnerStop);
		    ArrayAdapter<String> adapter = new ArrayAdapter<String>(this,
		        android.R.layout.simple_spinner_item, northArray);
		    adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
		    spinner.setAdapter(adapter);
		    
		  //GETS SPINNER SELECTED ITEM and POSITION on the ADAPTER
			String selectedStop=spinner.getSelectedItem().toString();
			int selectedStopPosition=spinner.getSelectedItemPosition();
			
			//Only case - for testing
			if(selectedStop.equals("IIT Tower (10 West 35th)")){
			    populateNorthSchedule();
			}
		}
		
		public void populateNorthSchedule(){
			final Spinner spinner2 = (Spinner) findViewById(R.id.spinnerSchedule);
		    ArrayAdapter<String> adapter = new ArrayAdapter<String>(this,
		        android.R.layout.simple_spinner_item, northArray1);
		    adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
		    spinner2.setAdapter(adapter);
		    
		    buttonSetReminderListener();
		}
		
		public void buttonSetReminderListener(){
			Button btnSetReminder = (Button) findViewById(R.id.setAlarm);
			btnSetReminder.setOnClickListener(new OnClickListener() {
				public void onClick(View v) {
					createReminder();
			
				}
			}
			);		
		}
		
		
		//TODO Correct logic to show the alarm according to the chosen schedule//////////////////////////////////////////////////////////////////////////////
		/*
		public void createReminder(){
		Toast.makeText(this, "Reminder Set", Toast.LENGTH_LONG);
		
		 // get a Calendar object with current time
		 Calendar cal = Calendar.getInstance();
		 // add 5 minutes to the calendar object
		 cal.add(Calendar.MINUTE, 1);
		 Intent intent = new Intent(this, AlarmReceiver.class);
		 intent.putExtra("alarm_message", "O'Doyle Rules!");
		 // In reality, you would want to have a static variable for the request code instead of 192837
		 PendingIntent sender = PendingIntent.getBroadcast(this, 192837, intent, PendingIntent.FLAG_UPDATE_CURRENT);
		 
		 // Get the AlarmManager service
		 AlarmManager am = (AlarmManager) getSystemService(ALARM_SERVICE);
		 am.set(AlarmManager.RTC_WAKEUP, cal.getTimeInMillis(), sender);
		 }*/
	
		
		//The alarm is created and showed imediatelly - Couldnt make it work programatically
		public void createReminder(){
			NotificationCompat.Builder mBuilder = 
					new NotificationCompat.Builder(this)
				    .setSmallIcon(R.drawable.bus_reminder)
				    .setContentTitle("ShuttleBus IIT ALERT")
				    .setContentText("Your bus is about to arrive");
			
			
			// Creates an explicit intent for an Activity in your app
			Intent resultIntent = new Intent(this, MainActivity.class);

			// The stack builder object will contain an artificial back stack for the
			// started Activity.
			// This ensures that navigating backward from the Activity leads out of
			// your application to the Home screen.
			TaskStackBuilder stackBuilder = TaskStackBuilder.create(this);
			// Adds the back stack for the Intent (but not the Intent itself)
			stackBuilder.addParentStack(MainActivity.class);
			// Adds the Intent that starts the Activity to the top of the stack
			stackBuilder.addNextIntent(resultIntent);
			PendingIntent resultPendingIntent =
			        stackBuilder.getPendingIntent(
			            0,
			            PendingIntent.FLAG_UPDATE_CURRENT
			        );
			mBuilder.setContentIntent(resultPendingIntent);
			NotificationManager mNotificationManager =
			    (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
			int mId = 001;
			// mId allows you to update the notification later on.
			mNotificationManager.notify(mId, mBuilder.build());
			
			 //Set the pattern for vibration   
	        long pattern[]={0,200,100,300,400};
	 
	        //Start the vibration
	       Vibrator vibrator = (Vibrator)getSystemService(Context.VIBRATOR_SERVICE);
	        //start vibration with repeated count, use -1 if you don't want to repeat the vibration
	        vibrator.vibrate(5000);    
		}
   			
		public void populateSouthSpinner(){
			String direction="SouthBound";//south
			final Spinner spinner = (Spinner) findViewById(R.id.spinnerStop);
		    ArrayAdapter<String> adapter = new ArrayAdapter<String>(this,
		        android.R.layout.simple_spinner_item, southArray);
		    adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
		    spinner.setAdapter(adapter);
		}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.reminder, menu);
		return true;
	}

	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		// Handle action bar item clicks here. The action bar will
		// automatically handle clicks on the Home/Up button, so long
		// as you specify a parent activity in AndroidManifest.xml.
		int id = item.getItemId();
		if (id == R.id.action_settings) {
			return true;
		}
		if (id == R.id.action_home) {
			Intent intent = new Intent(this, MainActivity.class);
	        startActivity(intent);
		}
		if (id == R.id.action_tracker) {
			Intent intent = new Intent(this, TrackBus.class);
	        startActivity(intent);
		}
		if (id == R.id.action_feedback) {
			Intent intent = new Intent(this, Feedback.class);
	        startActivity(intent);
		}
		return super.onOptionsItemSelected(item);
	}
}
