package com.example.shuttlebus;

import java.io.BufferedReader;
import java.io.DataInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.UnsupportedEncodingException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collection;
import java.util.Date;
import java.util.List;
import java.util.Scanner;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

public class ShowSchedule extends Activity {

  //SCHEDULE DATA
	final ArrayList<String> northArray1 = new ArrayList<String>();  
	public void addElements(){
	northArray1.add("IIT Tower (10 West 35th)"); northArray1.add("6:24 AM"); northArray1.add("6:54 AM");	northArray1.add("7:24 AM");	northArray1.add("7:59 AM");
	northArray1.add("8:29 AM");	northArray1.add("3:54 AM");	northArray1.add("4:24 AM");	northArray1.add("4:49 AM");	northArray1.add("5:09 PM*");	
	northArray1.add("5:29 PM*");	northArray1.add("8:02 PM");	northArray1.add("9:09 PM");}
      
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
				
		setContentView(R.layout.activity_show_schedule);
		
		Intent intent = getIntent();
		final String direction = intent.getStringExtra("direction");	
		final String selectedStop = intent.getStringExtra("selectedStop");
		
		//shows Direction and Selected Stop
		TextView textView1 = (TextView)findViewById(R.id.direction_title);
		textView1.setText(direction);
		
		TextView textView2 = (TextView)findViewById(R.id.stops_title);
		textView2.setText(selectedStop);
		
		//GET CURRENT TIME 
		 SimpleDateFormat dateFormat = new SimpleDateFormat("hh:mm a");
		   //get current date time with Date()
		   Date date = new Date();
		   //get current date time with Calendar()
		   Calendar cal = Calendar.getInstance();
		   String time = dateFormat.format(cal.getTime());
		
		 //populates arraylist with schedule data
		addElements();
		
		//PRINTS NEXT 3 STOPS
			try {
				print3Stops(selectedStop, time);
			} catch (ParseException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		 
	
		ImageButton ib = (ImageButton) findViewById(R.id.fullSchedule);
		ib.setOnClickListener(new View.OnClickListener() {
        @Override
        public void onClick(View v) {
        	//open another activity to show the full schedule
        	//TODO send parameters to show full schedule array list
            showFullSchedule(direction, selectedStop);
        }
    });
    
	}
	
	//TODO CORRECT LOGIC - APP IS CRASHING
	//PRINTS NEXT 3 ARRIVALS and ESTIMATED ARRIVAL
	public void print3Stops(String selectedStop, String time) throws ParseException{
		//checks if the selected stop is the same of the arraylist
		if(selectedStop.equals(northArray1.get(0))){
			//if so, compare current time to schedule to find the next 3 stops
			Toast.makeText(this, northArray1.get(0)+time, Toast.LENGTH_LONG).show();
		

			SimpleDateFormat dateFormat = new SimpleDateFormat("hh:mm a");
			boolean done=false;
			
			while(done==false){
				for(int i=1;i < northArray1.size();i++){  
					Date before = dateFormat.parse(northArray1.get(i));
					Date after = dateFormat.parse(northArray1.get(i+2));
					Date ctime = dateFormat.parse(time);
					
					if(ctime.after(before)&& ctime.before(after)){
						String next1 = northArray1.get(i+1);
						String next2 = northArray1.get(i+2);
						String next3 = northArray1.get(i+3);
						done=true;
						
						TextView arrival = (TextView)findViewById(R.id.arrival_time);
						arrival.setText(next1);
						
						TextView nexttime1 = (TextView)findViewById(R.id.next3stops1);
						nexttime1.setText(next1);
						
						TextView nexttime2 = (TextView)findViewById(R.id.next3stops2);
						nexttime2.setText(next2);
						
						TextView nexttime3 = (TextView)findViewById(R.id.next3stops3);
						nexttime3.setText(next3);
					}
				}
			}
			

		}
		

		
	}
	
	private void showFullSchedule(String direction, String selectedStop) {
		Intent intent2 = new Intent(this, FullSchedule.class);
		intent2.putExtra("direction",direction);
		intent2.putExtra("selectedStop", selectedStop);
        startActivity(intent2);
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.show_schedule, menu);
		return true;
	}

	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		// Handle action bar item clicks here. The action bar will
		// automatically handle clicks on the Home/Up button, so long
		// as you specify a parent activity in AndroidManifest.xml.
		int id = item.getItemId();
		if (id == R.id.action_settings) {
			return true;
		}
		if (id == R.id.action_home) {
			Intent intent = new Intent(this, MainActivity.class);
	        startActivity(intent);
		}
		if (id == R.id.action_reminder) {
			Intent intent = new Intent(this, Reminder.class);
	        startActivity(intent);
		}
		if (id == R.id.action_feedback) {
			Intent intent = new Intent(this, Feedback.class);
	        startActivity(intent);
		}
		return super.onOptionsItemSelected(item);
	}
}
