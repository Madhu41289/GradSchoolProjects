package com.example.shuttlebus;

import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.Arrays;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.TextView;

public class FullSchedule extends Activity {
			
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_full_schedule);
		
		Intent intent = getIntent();
		String direction = intent.getStringExtra("direction");
		String selectedStop = intent.getStringExtra("selectedStop");
		
		//shows Direction and Selected Stop
		TextView textView1 = (TextView)findViewById(R.id.directionTitle_);
		textView1.setText(direction);
						
		//TODO - CORRECT LOGIC to remove the [ ]
		
		  //SCHEDULE DATA
			String[] northArray1 ={"IIT Tower (10 West 35th)","6:24 AM", "6:54 AM", "7:24 AM", "7:59 AM", "8:29 AM", "3:54 AM", "4:24 AM", 
					"4:49 AM", "5:09 PM*","5:29 PM*", "8:02 PM", "9:09 PM"};
						
			TextView stop = (TextView)findViewById(R.id.stop);
			stop.setText(Arrays.toString(northArray1).replaceAll(",", "\n"));
		 
		
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.full_schedule, menu);
		return true;
	}

	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		// Handle action bar item clicks here. The action bar will
		// automatically handle clicks on the Home/Up button, so long
		// as you specify a parent activity in AndroidManifest.xml.
		int id = item.getItemId();
		if (id == R.id.action_settings) {
			return true;
		}
		if (id == R.id.action_reminder) {
			Intent intent = new Intent(this, Reminder.class);
	        startActivity(intent);
		}
		if (id == R.id.action_tracker) {
			Intent intent = new Intent(this, TrackBus.class);
	        startActivity(intent);
		}
		if (id == R.id.action_feedback) {
			Intent intent = new Intent(this, Feedback.class);
	        startActivity(intent);
		}
		if (id == R.id.action_home) {
			Intent intent = new Intent(this, MainActivity.class);
	        startActivity(intent);
		}
		return super.onOptionsItemSelected(item);
	}
}
