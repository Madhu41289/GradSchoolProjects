package com.example.shuttlebus;


import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

import android.app.Activity;
import android.content.Intent;
import android.content.res.Resources;
import android.graphics.Color;
import android.os.Bundle;
import android.text.format.DateFormat;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemSelectedListener;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends Activity {
	
	public MainActivity(){
		
	}
	
	//STOPS
	  final String[] northArray = new String[] { "IIT Tower (10 West 35th)", "33rd and Federal - HH Lot",
		      "31st and Federal", "26th and Princeton", "225 S. Canal - Union Station", "Madison Street (btwn Canal and Clinton) - N�Western Station",
		      "Adams and Jefferson (SE Corner) - Adams St. Campus" };
	  
	  final String[] southArray = new String[] { "Adams and Jefferson (SE Corner) - Adams St. Campus", "Clinton Street (btwn Washington and Madison) - N�Western Station",
			  "Clinton and Adams (SW Corner) - Union Station", "26th and Princeton", "31st and Dearborn", "Gunsaulus Hall - 32nd and Michigan", "31st and Indiana", "32nd and King Drive",
			  "Residence Halls (NE Corner) - 33rd and Michigan", "IIT Tower (10 West 35th)"};


	  
	//BUTTON OK LISTENER
	public void buttonOkListener() {
		 
		final RadioGroup radioDirections = (RadioGroup) findViewById(R.id.rg_directions);
		Button btnOk = (Button) findViewById(R.id.ok);
		
		btnOk.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
			// get selected radio button from radioGroup
			int selectedId = radioDirections.getCheckedRadioButtonId();
			// find the radiobutton by returned id
			RadioButton rb = (RadioButton) findViewById(selectedId);
			System.out.println(selectedId);
			
						if (rb.getText().equals("NorthBound")){
							populateNorthSpinner();							
						}
						
						if (rb.getText().equals("SouthBound")){
							populateSouthSpinner();
						}
						
						else
						buttonOkListener();
			}
		});
	}//button listener
	
	//BUTTON SEESCHEDULE LISTENER
		public void buttonSeeScheduleListener(final String direction, Spinner spinner) {
			final Spinner spinnerStops = spinner;
			Button btnSeeSchedule = (Button) findViewById(R.id.see_schedule);
			btnSeeSchedule.setOnClickListener(new OnClickListener() {
				@Override
				public void onClick(View v) {
					
					//GETS SPINNER SELECTED ITEM and POSITION on the ADAPTER
					String selectedStop=spinnerStops.getSelectedItem().toString();
					int selectedStopPosition=spinnerStops.getSelectedItemPosition();
									   
					   //sends parameters to other activity
						Intent i = new Intent(getApplicationContext(), ShowSchedule.class);
						i.putExtra("direction",direction);
						i.putExtra("selectedStop", selectedStop);
				
						   	   
					if(direction.equals("NorthBound")){
						//shows Schedule screen
						
				    	//Toast.makeText(MainActivity.this,
						startActivity(i);

					}
					
					if(direction.equals("SouthBound")){
						//TODO - Include code to show the next buses on the selected stop
					}
				}
				
			});
	
		}//button listener
		
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);

		buttonOkListener();
	}
	
	
	public void populateNorthSpinner(){
		String direction="NorthBound";//north
		final Spinner spinner = (Spinner) findViewById(R.id.spinner_stops);
	    ArrayAdapter<String> adapter = new ArrayAdapter<String>(this,
	        android.R.layout.simple_spinner_item, northArray);
	    adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
	    spinner.setAdapter(adapter);
	    
	    buttonSeeScheduleListener(direction, spinner);
	}
		
	public void populateSouthSpinner(){
		String direction="SouthBound";//south
		final Spinner spinner = (Spinner) findViewById(R.id.spinner_stops);
	    ArrayAdapter<String> adapter = new ArrayAdapter<String>(this,
	        android.R.layout.simple_spinner_item, southArray);
	    adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
	    spinner.setAdapter(adapter);
	    
	    buttonSeeScheduleListener(direction, spinner);
	}
		

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.main, menu);
		return true;
	}

	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		// Handle action bar item clicks here. The action bar will
		// automatically handle clicks on the Home/Up button, so long
		// as you specify a parent activity in AndroidManifest.xml.
		int id = item.getItemId();
		if (id == R.id.action_settings) {
			return true;
		}
		if (id == R.id.action_reminder) {
			Intent intent = new Intent(this, Reminder.class);
	        startActivity(intent);
		}
		if (id == R.id.action_tracker) {
			Intent intent = new Intent(this, TrackBus.class);
	        startActivity(intent);
		}
		if (id == R.id.action_feedback) {
			Intent intent = new Intent(this, Feedback.class);
	        startActivity(intent);
		}
		return super.onOptionsItemSelected(item);
	}
}

