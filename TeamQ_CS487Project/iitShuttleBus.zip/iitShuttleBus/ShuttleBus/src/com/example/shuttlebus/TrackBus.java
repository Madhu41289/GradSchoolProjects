package com.example.shuttlebus;

import java.util.Locale;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Spinner;
import android.widget.Toast;

public class TrackBus extends Activity {
	
	//STOPS
	  final String[] northArray = new String[] { "IIT Tower (10 West 35th)", "33rd and Federal - HH Lot",
		      "31st and Federal", "26th and Princeton", "225 S. Canal - Union Station", "Madison Street (btwn Canal and Clinton) - N�Western Station",
		      "Adams and Jefferson (SE Corner) - Adams St. Campus" };

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_track_bus);
		buttonOkListener();

	}
	
	public void buttonOkListener() {
		final RadioGroup radioDirections = (RadioGroup) findViewById(R.id.radioGroupT);
		Button btnOk = (Button) findViewById(R.id.ok3);
		
		btnOk.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
			// get selected radio button from radioGroup
			int selectedId = radioDirections.getCheckedRadioButtonId();
			// find the radiobutton by returned id
			RadioButton rb = (RadioButton) findViewById(selectedId);
			System.out.println(selectedId);
			
						if (rb.getText().equals("NorthBound")){
							populateNorthSpinner();		
						}
						
						else
							buttonOkListener();
			}
		});
	}//button listener
	
	public void populateNorthSpinner(){
		final Spinner spinner = (Spinner) findViewById(R.id.spinnerStops1);
	    ArrayAdapter<String> adapter = new ArrayAdapter<String>(this,
	        android.R.layout.simple_spinner_item, northArray);
	    adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
	    spinner.setAdapter(adapter);	
	    String selectedStop=spinner.getSelectedItem().toString();
	    
	    callListeners(selectedStop);
	}

	public void callListeners(String selectedStop){
	    btnTrackBusListener(selectedStop);
	    btnSeeStatusListener(selectedStop);		
	}
	
	public void btnTrackBusListener(final String selectedStop) {
		Button btnTrack = (Button) findViewById(R.id.btn_track);
		
		btnTrack.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				trackBus(selectedStop);
			}
		});
	}//button listener

		
		public void trackBus(String selectedStop){
			Toast.makeText(this, "Track", Toast.LENGTH_LONG).show();

			//The adress typed now is just for testing the intent. The application should search the address based on the selectedStop name and set current location using the gps
		    String uri = String.format(Locale.ENGLISH, "http://maps.google.com/maps?daddr=41.838682,-87.627353", 41.8312838f, -87.62722409999998f, "Where the Shuttle is at");
	        Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(uri));
	        intent.setClassName("com.google.android.apps.maps", "com.google.android.maps.MapsActivity");
	        try
	        {
	            startActivity(intent);
	        }
	        catch(ActivityNotFoundException ex)
	        {
	            try
	            {
	                Intent unrestrictedIntent = new Intent(Intent.ACTION_VIEW, Uri.parse(uri));
	                startActivity(unrestrictedIntent);
	            }
	            catch(ActivityNotFoundException innerEx)
	            {
	                Toast.makeText(this, "Please install a maps application", Toast.LENGTH_LONG).show();
	            }
	        }
		}

		public void btnSeeStatusListener(final String selectedStop) {
			Button btnSeeStatus = (Button) findViewById(R.id.btn_status);
			
			btnSeeStatus.setOnClickListener(new OnClickListener() {
				@Override
				public void onClick(View v) {
					seeStatus(selectedStop);
				}
			});
		}//button listener
		
		public void seeStatus(String selectedStop){
			String status="On time";
			Toast.makeText(this, "Your bus status to the selected stop : " +selectedStop+ "is: " +status, Toast.LENGTH_LONG).show();
	
		}
		
	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.track_bus, menu);
		return true;
	}

	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		// Handle action bar item clicks here. The action bar will
		// automatically handle clicks on the Home/Up button, so long
		// as you specify a parent activity in AndroidManifest.xml.
		int id = item.getItemId();
		if (id == R.id.action_settings) {
			return true;
		}
		if (id == R.id.action_home) {
			Intent intent = new Intent(this, MainActivity.class);
	        startActivity(intent);
		}
		if (id == R.id.action_reminder) {
			Intent intent = new Intent(this, Reminder.class);
	        startActivity(intent);
		}
		if (id == R.id.action_feedback) {
			Intent intent = new Intent(this, Feedback.class);
	        startActivity(intent);
		}
		return super.onOptionsItemSelected(item);
	}
}
