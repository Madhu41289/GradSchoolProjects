package com.example.shuttlebus;

import android.os.Handler;

/**
 * Created by Sowi on 4/25/15.
 */
public class ProblemReportSender  {


    /**
     * Generates xml report from raw data.
     *
     * @param description
     *            Description of problem.
     * @param user_email
     *            Email id of user, not sent if null.
     * @return XML report from raw data passed in.
     */
    private static String generateReport(String description, String user_email) {
        StringBuilder sb = new StringBuilder();
        sb.append("<description>");
        sb.append(description);
        sb.append("</description>");
        if (user_email != null) {
            sb.append("<user_email>");
            sb.append(user_email);
            sb.append("</user_email>");
        }
        return sb.toString();
    }
}