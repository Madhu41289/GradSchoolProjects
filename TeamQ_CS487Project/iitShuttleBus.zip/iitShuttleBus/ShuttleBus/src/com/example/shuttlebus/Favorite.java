package com.example.shuttlebus;

/**
 * Created by Sowi on 4/25/15.
 */
public class Favorite {
    public int compareTo(Favorite favorite) {
        return 0;
    }
}
