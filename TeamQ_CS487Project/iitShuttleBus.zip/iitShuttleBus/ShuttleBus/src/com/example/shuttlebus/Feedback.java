package com.example.shuttlebus;

import java.util.Properties;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.os.Message;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.RatingBar;
import android.widget.TextView;
import android.widget.Toast;

public class Feedback extends Activity {

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_feedback);
		
		//id
		final TextView studentID = (TextView) findViewById(R.id.studentID);
		final String id = studentID.getText().toString();
		//email
		final TextView email = (TextView) findViewById(R.id.email);
		final String emailAdress = email.getText().toString();
		//id
		final TextView comments = (TextView) findViewById(R.id.comments);
		final String message = comments.getText().toString();
		
		final String sendTo = "adossant@hawk.iit.edu";
		
		final RatingBar ratingBar = (RatingBar) findViewById(R.id.ratingBar1);
   		//get rating value
    	
    	Button button = (Button) findViewById(R.id.sendMail);
        button.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View view) {	
            sendEmail(id, emailAdress, message, sendTo, ratingBar);
            }
        });
		
	}
	
	public void sendEmail(String id, String emailAdress, String message, String sendTo, RatingBar ratingBar){
      //  Toast.makeText(this, ratingValue, Toast.LENGTH_LONG).show();
        final double rating = ratingBar.getRating();
        final String ratingValue = Double.toString(rating);
            
        	String subject = id;
            String messageMail = message + "\n" + "Rating Value given is: " + ratingValue;
            String to = sendTo;

            Intent emailActivity = new Intent(Intent.ACTION_SEND);

            //set up the recipient address
            emailActivity.putExtra(Intent.EXTRA_EMAIL, new String[] { to });
            //set up the email subject
            emailActivity.putExtra(Intent.EXTRA_SUBJECT, subject);


            //set up the message body
            emailActivity.putExtra(Intent.EXTRA_TEXT, messageMail);
            emailActivity.setType("message/rfc822");
            startActivity(Intent.createChooser(emailActivity, "Select your Email Provider :"));
	}
	
	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.feedback, menu);
		return true;
	}
	
	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		// Handle action bar item clicks here. The action bar will
		// automatically handle clicks on the Home/Up button, so long
		// as you specify a parent activity in AndroidManifest.xml.
		int id = item.getItemId();
		if (id == R.id.action_settings) {
			return true;
		}
		if (id == R.id.action_reminder) {
			Intent intent = new Intent(this, Reminder.class);
	        startActivity(intent);
		}
		if (id == R.id.action_tracker) {
			Intent intent = new Intent(this, TrackBus.class);
	        startActivity(intent);
		}
		if (id == R.id.action_home) {
			Intent intent = new Intent(this, MainActivity.class);
	        startActivity(intent);
		}
		return super.onOptionsItemSelected(item);
	}
}
